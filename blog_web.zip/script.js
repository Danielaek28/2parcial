document.addEventListener('DOMContentLoaded', function() {
    const newPostForm = document.getElementById('newPostForm');
    const postList = document.getElementById('postList');

    newPostForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const postTitle = document.getElementById('postTitle').value;
        const postDescription = document.getElementById('postDescription').value;
        const postAuthor = document.getElementById('postAuthor').value;
        const postImage = document.getElementById('postImage').value;
        const postDate = new Date().toLocaleDateString();

        const postHTML = `
            <div class="post">
                <h3>${postTitle}</h3>
                <p>${postDescription}</p>
                <img src="${postImage}" alt="${postTitle}">
                <div class="details">
                    <p>Autor: ${postAuthor}</p>
                    <p>Fecha de publicación: ${postDate}</p>
                </div>
            </div>
            `;

        postList.innerHTML += postHTML;

        newPostForm.reset();
    });
});